•  Title and purpose of the application
Title: C195 Scheduling App AKA Global Consulting LLC Customer Appointment system

Purpose: - This application accesses SQL data tables and makes changes such as customer changes and appointment creation/change. 


•  Author, contact information, student application version, and date

Author: Keith Hudson
Contact Email: khuds95@my.wgu.edu
Version: 1.0
Date: July 7 2022


•  IDE including version number (e.g., IntelliJ Community 2020.01), full JDK of version used (e.g., Java SE 17.0.1), and JavaFX version compatible with JDK version (e.g. JavaFX-SDK-17.0.1)

IDE: IntelliJ IDEA 2021.1.3 (Community Edition)
     Build #IC-211.7628.21, built on June 30, 2021
     Runtime version: 11.0.11+9-b1341.60 amd64
     VM: OpenJDK 64-Bit Server VM by JetBrains s.r.o.
     Windows 10 10.0
     GC: G1 Young Generation, G1 Old Generation
     Memory: 768M
     Cores: 4
     Kotlin: 211-1.4.32-release-IJ7628.19

JDK: Java 17.0.1

JavaFX: 17.0.1


•  Directions for how to run the program
Clicking Run within the IDE will start the program and present a login page. Login with username: admin and password: admin in order to proceed. A menu screen wiill load with the options of Customer View, Appointment View and Report Page.  The Cusomter View will allow you to view, create, update and delete Customers from the MySQL server. The Appointment View allows you to view, create, update and delete Appointments from the MySQL Server. The Report Page shows the user various data from the server. The user is able to navigate back to the the menu screen via the Back button at the top right of the window. 


•  A description of the additional report of your choice you ran in part A3f
The additional report I included was a total number of appointments. This is a quick and easy way to see if customers are setting up appointments.


•   MySQL Connector driver version number
mysql-connector-java-8.0.29